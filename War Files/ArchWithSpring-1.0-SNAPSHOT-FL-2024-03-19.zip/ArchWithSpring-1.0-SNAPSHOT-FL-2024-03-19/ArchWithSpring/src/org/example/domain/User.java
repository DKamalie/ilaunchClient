package org.example.domain;

public class User {
    protected String userId;
    protected String name;
    protected String surname;
    protected String username;
    protected String email;
    protected boolean active;
    protected String role;
}
